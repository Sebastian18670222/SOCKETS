package socket;
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MainCliente {

    public static void main(String args[]) {
        Socket cliente = null;
        DataInputStream entrada = null;
        DataOutputStream salida = null;

        String ipServidor ="127.0.0.1";	  
        //nos conectamos al localhost a traves de esta dirección IP

        //if (cliente != null && salida != null && entrada!= null) {	
        try {	

            cliente = new Socket(ipServidor, 2019);  
            //asignamos este numero de puerto
            entrada = new DataInputStream(cliente.getInputStream());
            // será lo que enviaremos al servidor	
            salida = new DataOutputStream(cliente.getOutputStream());
            // será lo que nos devuelva el servidor	
            System.out.println("Cliente Conectado...");
        }
        catch (UnknownHostException excepcion) {
            System.err.println("El servidor no está levantado");
        }
        catch (Exception e) {
            System.err.println("Error: " + e );
        }

        try {
            Scanner leer = new Scanner(System.in);
            System.out.println("SELECCIONA LA OPERACIÓN A REALIZAR");
            System.out.println("1 Suma");
            System.out.println("2 Resta");
            System.out.println("3 Multiplicación");
            System.out.println("4 División");
            int opcion = leer.nextInt();
            if(opcion >= 1 && opcion <= 4){
                System.out.println("INGRESA NUMERO UNO");
                double num1 = leer.nextDouble();
                System.out.println("INGRESA NUMERO DOS");
                double num2 = leer.nextDouble();
                String opciones = String.valueOf(opcion)+","+String.valueOf(num1)+","+String.valueOf(num2);
                salida.writeBytes(opciones+"\n");
                String linea_recibida;
                linea_recibida = entrada.readLine();
                System.out.println("SERVIDOR DICE: ");
                System.out.println(linea_recibida);
            }else{
                System.out.println("Lo siento opcion no valida");
            }
            salida.close();
            entrada.close();
            cliente.close();
        }
        catch (UnknownHostException excepcion) {
            System.err.println("No encuentro el servidor en la dirección" + ipServidor);
        }
        catch (IOException excepcion) {
            System.err.println("Error de entrada/salida");
        }
        catch (Exception e) {
            System.err.println("Error: " + e );
        }
    }
}